package Exceptions;

public class InvalidNumberException extends Exception {
long mob;

public InvalidNumberException(long mob) {
	super();
	this.mob = mob;
}
}
