package Exceptions;

public class InvalidBalanceException extends Exception {
long bal;

public InvalidBalanceException(long bal) {
	super();
	this.bal = bal;
}
}
