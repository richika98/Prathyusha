package Exceptions;

public class InvalidAccountNumberException extends Exception {
long accNum;

public InvalidAccountNumberException(long accNum) {
	super();
	this.accNum = accNum;
}
}
