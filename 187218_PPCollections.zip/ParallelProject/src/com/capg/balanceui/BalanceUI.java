package com.capg.balanceui;

import java.util.Scanner;
import java.util.regex.Pattern;

import javax.naming.InvalidNameException;

import com.cap.balancebean.BankDetails;
import com.cap.balancebean.BankTransaction;
import com.capg.balanceservice.BalanceService;

import Exceptions.InvalidAccountNumberException;
import Exceptions.InvalidBalanceException;
import Exceptions.InvalidNumberException;

public class BalanceUI {
	static BalanceService bs1 = new BalanceService();

	public static void main(String[] args)
			throws InvalidNameException, InvalidNumberException, InvalidBalanceException {
		int transid = 1000;
		while (true) {
			System.out.println("*********************************************");
			System.out.println("\tWelcome to Payment Wallet");
			System.out.println("*********************************************");
			System.out.println(
					"1.Create account\n2.Show balance\n3.Deposit\n4.Withdraw\n5.Fund Transfer\n6.Print Transactions\n7.Exit");
			Scanner sc = new Scanner(System.in);
			System.out.println("Please enter your choice");
			int ch = sc.nextInt();
			switch (ch) {

			// Create Account
			case 1:

				System.out.println("Enter your name:");
				String name = sc.next();
				try {
					bs1.validateName(name);
				} catch (InvalidNameException ie) {
					System.out.println("Name must start with capital letter");
					break;
				}
				System.out.println("Enter your mobile number");
				long mob = sc.nextLong();
				try {
					bs1.validateNumber(mob);
				} catch (InvalidNumberException ie) {
					System.out.println("Enter valid 10 digit mobile number");
					break;
				}
				System.out.println("Enter your password");
				String pass = sc.next();
				long accNum = mob + 1234; // Account is created
				int bal = 500;
				BankDetails bankDetails = new BankDetails(name, mob, bal, pass, accNum);
				BankDetails bd = bs1.add(bankDetails);
				System.out.println("Your details are:" + bd.getName() + " " + bd.getMob() + " " + " " + bd.getPass());
				System.out.println("Your account number is" + accNum);
				System.out.println("You have successfully created your account");
				System.out.println("Thankyou");
				break;

			// Show Balance
			case 2:
				try {
					System.out.println("Enter your account number");
					accNum = sc.nextLong();

					bs1.validateAccountNum(accNum);
				} catch (InvalidAccountNumberException ie) {
					System.out.println("Account doesnot exist!!Please provide valid account number");
					break;
				}
				BankDetails bank = bs1.getBankDetails(accNum);
				if (bank == null) {
					System.out.println("Account doesn't exists!!");
					break;
				}
				int showbal = bs1.getBal(accNum); // provides available balance in your account
				System.out.println("Current balance in your account is:" + " " + showbal);
				break;

			// Deposit
			case 3:
				try {
					System.out.println("Enter your account number");
					accNum = sc.nextLong();

					bs1.validateAccountNum(accNum);
				} catch (InvalidAccountNumberException ie) {
					System.out.println("Account doesnot exist!!Please provide valid account number");
					break;
				}
				BankDetails bank1 = bs1.getBankDetails(accNum);
				if (bank1 == null) {
					System.out.println("Account doesn't exists!!");
					break;
				}
				System.out.println("Enter the amount to deposit");
				long amt = sc.nextLong();

				bs1.validateBalance(amt);
				long deposit = bs1.deposit(accNum, amt); // deposits amount in your account
				System.out.println("Amount credited successfully and available balance is:" + " " + deposit);
				transid = transid + 1;
				BankTransaction banktrans = new BankTransaction(accNum, accNum, amt, "deposit");// prints all deposited
																								// transactions
				bs1.setBankTransaction(accNum, banktrans);
				break;

			// Withdraw
			case 4:
				try {
					System.out.println("Enter your account num");
					accNum = sc.nextLong();

					bs1.validateAccountNum(accNum);
				}

				catch (InvalidAccountNumberException ie) {
					System.out.println("Invalid Account number!!Please provide valid account number");
					break;
				}
				BankDetails bank2 = bs1.getBankDetails(accNum);
				if (bank2 == null) {
					System.out.println("Account doesn't exists!!");
					break;
				}
				System.out.println("Enter the amount to withdraw");
				int amt1 = sc.nextInt();
				bs1.validateBalance(amt1);
				if (amt1 > bank2.getBal()) {
					System.out.println("Insufficient funds to withdraw!");
					break;
				}
				long withdraw = bs1.withdraw(accNum, amt1); // withdraws amount from your account
				System.out.println("Amount has debited from your account and remaining balance is:" + withdraw);
				transid = transid + 1;
				BankTransaction banktrans2 = new BankTransaction(accNum, accNum, amt1, "withdraw"); // prints all
																									// withdraw
																									// transactions
				bs1.setBankTransaction(accNum, banktrans2);
				break;

			// Fund Transfer
			case 5:
				try {
					System.out.println("Enter your account number");
					accNum = sc.nextLong();

					bs1.validateAccountNum(accNum);
				} catch (InvalidAccountNumberException ie) {
					System.out.println("Account doesnot exist!!Please provide valid account number");
					break;
				}
				BankDetails bank3 = bs1.getBankDetails(accNum);
				if (bank3 == null) {
					System.out.println("Account doesn't exists!!");
					break;
				}
				System.out.println("Enter the Account number to transfer amount");
				long accNum1 = sc.nextLong();
				System.out.println("Enter the amount to transfer");
				long tamt1 = sc.nextLong();
				long transfer = bs1.transfer(accNum, accNum1, tamt1);// transfers amount from your account to other
																		// account
				System.out.println("Amount transferred to" + " " + accNum1 + " " + "is" + " " + tamt1);
				System.out.println("Available balance after transfer is:" + " " + transfer);
				transid = transid + 1;
				BankTransaction banktrans3 = new BankTransaction(accNum, accNum1, tamt1, "transfer"); // prints
																										// transferred
																										// transactions
				bs1.setBankTransaction(accNum, banktrans3);
				break;

			// Print Transactions
			case 6:
				try {
					System.out.println("Enter your account number");
					accNum = sc.nextLong();
					bs1.validateAccountNum(accNum);
				} catch (InvalidAccountNumberException ie) {
					System.out.println("Account doesnot exist!!Please provide valid account number");
					break;
				}
				BankDetails bank4 = bs1.getBankDetails(accNum);
				if (bank4 == null) {
					System.out.println("Account doesn't exists!!");
					break;
				}
				System.out.println("Transactions of" +"  " +accNum); // shows all transactions of the provided accountnumber
				System.out.println("");
				bs1.transaction(accNum);
				break;

			// Exit
			case 7:
				System.exit(0);

			}
		}
	}
}