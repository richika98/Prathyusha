package com.capg.balanceservice;

import com.cap.balancebean.BankDetails;
import com.cap.balancebean.BankTransaction;

public interface BalanceServiceI {

	public BankDetails add(BankDetails bankDetails);
	public int getBal(long accNum);
	public long withdraw(long accNum, long amt1);
	long deposit(long accNum, long amt);
	public long transfer(long accNum, long accNum1, long tamt1);
	public void transaction(long accNum);
	public void setBankTransaction(long accNum, BankTransaction banktrans);
	public BankDetails getBankDetails(long accNum);
}
