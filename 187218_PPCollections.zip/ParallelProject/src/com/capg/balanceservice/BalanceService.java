package com.capg.balanceservice;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.regex.Pattern;

import javax.naming.InvalidNameException;

import com.cap.balanceDAO.BalanceDAO;
import com.cap.balancebean.BankDetails;
import com.cap.balancebean.BankTransaction;

import Exceptions.InvalidAccountNumberException;
import Exceptions.InvalidBalanceException;
import Exceptions.InvalidNumberException;


public  class BalanceService implements BalanceServiceI  {

	BalanceDAO baldao=new BalanceDAO();
	public int getBal(long accNum) {
		// TODO Auto-generated method stub
		int bdd=baldao.getbal(accNum);
		return bdd;	
	}

@Override
	public BankDetails add(BankDetails bankDetails) {
		
		BankDetails bd1=baldao.setData(bankDetails);
		return bd1;
	}

@Override
public long deposit(long accNum, long amt) {
	// TODO Auto-generated method stub
	long bal=baldao.deposit(accNum,amt);
	
	return bal;
	
}

public long withdraw(long accNum, long amt1) {
	// TODO Auto-generated method stub
	long bal1=baldao.withdraw(accNum,amt1);
	return bal1;
}

public long transfer(long accNum, long accNum1, long tamt1) {
	// TODO Auto-generated method stub
	long tran=baldao.transfer(accNum,accNum1,tamt1);
	return tran;
}

public void transaction(long accNum) {
	// TODO Auto-generated method stub
	ArrayList<BankTransaction> al=baldao.transaction(accNum);
	Iterator itr=al.iterator();
	while(itr.hasNext()) {
		System.out.println(itr.next());
	}	
}

public void setBankTransaction(long accNum, BankTransaction banktrans) {
	// TODO Auto-generated method stub
	baldao.setTransactionDao(accNum,banktrans);	
}

public boolean validateName(String name) throws InvalidNameException {
	// TODO Auto-generated method stub
	boolean res=Pattern.matches("[A-Z][a-z]*", name);
		if(res==false)
			throw new InvalidNameException(name);
		return res;
	
}

public boolean validateNumber(long mob) throws InvalidNumberException {
	// TODO Auto-generated method stub
	String mob1=Long.toString(mob);
	boolean num1=Pattern.matches("[6-9][0-9]{9}", mob1);
	if(num1==false)
		throw new InvalidNumberException(mob);
	return num1;
}

public void validateAccountNum(long accNum) throws InvalidAccountNumberException {
	// TODO Auto-generated method stub
	String amt1=Long.toString(accNum);
	int flag=0;
	char ch[]=amt1.toCharArray();
	if(ch.length==10)
	{
		for(int i=0;i<amt1.length();i++)
			if(!Character.isDigit(ch[i]))
				{flag=1;
		break;}
	}
	if(flag==1)
		throw new InvalidAccountNumberException(accNum);
	
}

public boolean validateBalance(long amt) throws InvalidBalanceException {
	// TODO Auto-generated method stub
	
	String amt1=Long.toString(amt);
boolean bal=Pattern.matches("[0-9]*",amt1);
	if(bal==false)
		throw new InvalidBalanceException(amt);
	return false;
}

@Override
public BankDetails getBankDetails(long accNum) {
	BankDetails bank=baldao.getBankDao(accNum);
	return bank;
}

}









	

	
	


	
	










