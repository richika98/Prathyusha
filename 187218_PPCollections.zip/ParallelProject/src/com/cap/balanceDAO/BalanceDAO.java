package com.cap.balanceDAO;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;

import com.cap.balancebean.BankDetails;
import com.cap.balancebean.BankTransaction;

public class BalanceDAO implements BalanceDaoI {
	HashMap<Long, BankDetails> hm;
	HashMap<BankTransaction,Long> banktrans;

	public BalanceDAO() {
		hm = new HashMap<Long, BankDetails>();
		banktrans=new HashMap<BankTransaction,Long>();
	}

	public int getbal(long accNum) {
		BankDetails acc = (BankDetails) hm.get(accNum);
		System.out.println(acc.getBal());
		int bal = (int) acc.getBal();
		return bal;

	}

	public BankDetails setData(BankDetails bd) {
		 hm.put(bd.getAccNum(),bd);
		BankDetails bankDetails= hm.get(bd.getAccNum());
		return bankDetails;
	}

	@Override
	public BankDetails add(BankDetails bd) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public long deposit(long accNum, long amt) {
		// TODO Auto-generated method stub
		BankDetails bde = (BankDetails) hm.get(accNum);
		long avlb = bde.getBal();
		long total = avlb + amt;
		bde.setBal(total);
		long balance = bde.getBal();
		return balance;
	}

	@Override
	public long withdraw(long accNum, long amt1) {
		// TODO Auto-generated method stub
		BankDetails bde = (BankDetails) hm.get(accNum);
		long avlb = bde.getBal();
		long withdraw = avlb - amt1;
		bde.setBal(withdraw);
		System.out.println(withdraw);
		return withdraw;
	}

	public long transfer(long accNum, long accNum1, long tamt1) {
		// TODO Auto-generated method stub
		BankDetails bde = (BankDetails) hm.get(accNum);
		long bal=bde.getBal();
		long tbal=bal-tamt1;
		bde.setBal(tbal);
		System.out.println(tbal);
		return tbal;
	}

	public ArrayList transaction(long accNum) {
		// TODO Auto-generated method stub
		ArrayList al=new ArrayList();
		Set s=banktrans.entrySet();
		Iterator itr=s.iterator();
		while(itr.hasNext()) {
			Entry e=(Entry) itr.next();
			Long l=(Long) e.getValue();
			BankTransaction key=(BankTransaction) e.getKey();
			if(l.equals(accNum)){
				al.add(key);
			}
		}
		
		return al;
	}

	public void setTransactionDao(long accNum, BankTransaction banktrans2) {
		// TODO Auto-generated method stub
		banktrans.put(banktrans2, accNum);
		
	}

	@Override
	public BankDetails getBankDao(long accNum) {
		BankDetails bank=hm.get(accNum);
		return bank;
	}

}
