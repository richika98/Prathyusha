package com.cap.balanceDAO;

import java.util.ArrayList;

import com.cap.balancebean.BankDetails;
import com.cap.balancebean.BankTransaction;

public interface BalanceDaoI {
	 BankDetails add(BankDetails bd);
	 public int getbal(long accNum); 
	long deposit(long accNum, long amt);
	long withdraw(long accNum, long amt1);
	public long transfer(long accNum, long accNum1, long tamt1);
	public ArrayList transaction(long accNum);
	public void setTransactionDao(long accNum, BankTransaction banktrans2);
	BankDetails getBankDao(long accNum);
}