package com.cap.balancebean;

public class BankDetails {
	private String name;
	private long mob;
	private long bal;
	private String pass;
	private long accNum;

	public BankDetails(String name, long mob, long bal, String pass, long accNum) {
		super();
		this.name = name;
		this.mob = mob;
		this.bal = bal;
		this.pass = pass;
		this.accNum = accNum;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getMob() {
		return mob;
	}

	public void setMob(long mob) {
		this.mob = mob;
	}

	public long getBal() {
		return bal;
	}

	public void setBal(long bal) {
		this.bal = bal;
	}

	public String getPass() {
		return pass;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}


	public long getAccNum() {
		return accNum;
	}

	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}

	@Override
	public String toString() {
		return "BankDetails [name=" + name + ", mob=" + mob + ", bal=" + bal + ", pass=" + pass + ", accNum=" + accNum + "]";
	}

}
