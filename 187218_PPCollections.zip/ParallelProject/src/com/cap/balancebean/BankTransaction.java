package com.cap.balancebean;
public class BankTransaction {
	private long transFrom;
	private long transTo;
	private long amount;
	private String type;
	
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
	public long getTransFrom() {
		return transFrom;
	}
	public void setTransFrom(int transFrom) {
		this.transFrom = transFrom;
	}
	public long getTransTo() {
		return transTo;
	}
	public void setTransTo(int transTo) {
		this.transTo = transTo;
	}
	public long getAmount() {
		return amount;
	}
	public void setAmount(long amount) {
		this.amount = amount;
	}
	
	public BankTransaction(long transFrom, long transTo, long amount,String type) {
		super();
		this.transFrom = transFrom;
		this.transTo = transTo;
		this.amount = amount;
		this.type = type;
	}
	@Override
	public String toString() {
		return "transFrom="        + transFrom + "       transTo="       + transTo + "       amount=" + amount + "       type="
				+ type + "      ";
	}
	
	

}
