import { Component, OnInit } from '@angular/core';
import { Employee, MyServiceService, Transactions } from '../my-service.service';
import {Router} from '@angular/router';
@Component({
  selector: 'app-employee-add',
  templateUrl: './employee-add.component.html',
  styleUrls: ['./employee-add.component.css']
})
export class EmployeeAddComponent implements OnInit {

  createdEmployee:Employee;
  createdTransaction:Transactions;

  router:Router;
  createdFlag:boolean=false;

  service:MyServiceService;

  constructor(service:MyServiceService,router:Router) 
  {
    this.service=service;
    this.router=router;
  }

  ngOnInit() {
  }

  add(data:any){
    data.caccount=data.cphone-100;
    data.cbalance=5000;
    
    this.createdEmployee=new Employee(data.caccount,data.cname,data.cphone,data.cpassword,data.ccity,data.cbalance);
    this.service.add(this.createdEmployee);
    
    this.createdTransaction=new Transactions(125,data.caccount,0,data.cbalance);
    this.service.addTransaction(this.createdTransaction)
    console.log(this.createdTransaction);

    alert("Account successfully registered");
    this.createdFlag=true;
    this.router.navigate(['app-employee-list']);
   }
}
