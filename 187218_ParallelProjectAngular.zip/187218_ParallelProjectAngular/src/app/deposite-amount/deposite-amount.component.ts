import { Component, OnInit, APP_INITIALIZER } from '@angular/core';
import { MyServiceService, Employee, Transactions } from '../my-service.service';


@Component({
  selector: 'app-deposite-amount',
  templateUrl: './deposite-amount.component.html',
  styleUrls: ['./deposite-amount.component.css']
})
export class DepositeAmountComponent implements OnInit {

  isLogin:boolean=true;
  employees:Employee[]=[];
  createdTransaction:Transactions;
  
  service:MyServiceService;
  constructor(service:MyServiceService) { 
    this.service=service;
    this.isLogin=this.service.isLogin;
  }

  depositeAmount(data:any){
    let tid:number;
    let caccount_first=data.caccount;
    let cbalance=data.cbalance;
    console.log(data)
    this.service.depositeBalance(caccount_first,cbalance);

    this.createdTransaction=new Transactions(cbalance*4,data.caccount,0,data.cbalance);
    this.service.addTransaction(this.createdTransaction)
  }


  ngOnInit() {
    this.service.fetchEmployees();
    this.employees=this.service.getEmployees();
  }

}
