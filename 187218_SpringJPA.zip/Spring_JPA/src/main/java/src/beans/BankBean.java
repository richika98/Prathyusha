package src.beans;

import java.io.Serializable;
import java.util.Arrays;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

import src.beans.Address;

@Entity
@Table(name="Banking")
public class BankBean implements Serializable{

	@Transient int i = 0;
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO,generator="my_seq_acc")
	@SequenceGenerator(name="my_seq_acc",sequenceName="seq_accno1")
	@Column
	private long accNo;
	

	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="address_id")
	private Address address;
	
	
	@Column(length=20)
	private String name;
	@Column(length=20)
	private long mobile;
	@Column(length=20)
	private long balance;
	@Column(length=20)
	private String password;
	@Column(length=20)
	private String tran;

	
public BankBean() {}

public Address getAddress() {
	return address;
}
public void setAddress(Address address) {
	this.address = address;
}
	public String getName() {
		return name;
	}

	public void setAccNo(long accNo) {
		this.accNo = accNo;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setTransaction(String tran) {
		this.tran = tran;
		i++;
	}



	public long getMobile() {
		return mobile;
	}

	public long getAccNo() {
		return accNo;
	}

	public long getBalance() {
		return balance;
	}

	public void setBalance(long bal) {
		this.balance = bal;
	}

	public boolean getPassword(String password) {
		if (this.password.equals(password))
			return true;
		else
			return false;

	}

	public String getPassword1() {
		return password;

	}

	public void setMobile(int mobile) {
		this.mobile = mobile;
	}

	public BankBean(String name, long mobile, String password, long bal, String tan,Address add)
			 {

		this.name = name;
		
		this.mobile = mobile;
		this.password = password;
		balance = bal;
		tran = tan;
		this.accNo = accNo;
	this.address=add;
		i++;

	}

	public String getTran() {
		return tran;
	}

	public void setTran(String tran) {
		this.tran = tran;
	}

	public String getPassword() {
		return password;
	}

	public void setMobile(long mobile) {
		this.mobile = mobile;
	}

	@Override
	public String toString() {
		return "CreateAccount [i=" + i + ", name=" + name + ",  mobile=" + mobile
				+ ", balance=" + balance + ", password=" + password + ", tran=" + tran + "]";
	}

	public void setPassword(String password) {
		this.password = password;
	}

}
