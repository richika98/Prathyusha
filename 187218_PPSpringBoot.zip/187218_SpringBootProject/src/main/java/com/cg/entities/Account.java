package com.cg.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@Entity
public class Account {
	@Id
	
	
	
	private String accountNumber;
	
	@NotBlank(message="Provide a name")
	@Size(min=3, max=30, message="Provide Proper Name")
	private String custName;
	
	@NotBlank(message="Provide a mobile number")
	@Size(min=10, max=10, message="Mobile should be of 10 digits")
	private String mobileNumber;
	
	
	private String accountType;
	
	@NotBlank(message="Provide an address")
	@Size(min=5, max=50, message="provide a proper address")
	private String custAddress;
	
	@Min(value=0,message="Balance cannot be less than 0")
	private long balance;
	
	
	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getCustAddress() {
		return custAddress;
	}

	public void setCustAddress(String custAddress) {
		this.custAddress = custAddress;
	}

	public long getBalance() {
		return balance;
	}

	public void setBalance(long balance) {
		this.balance = balance;
	}

	public Account(String custName, String mobileNumber, String accountType, String custAddress, long balance) {
		super();
		this.custName = custName;
		this.mobileNumber = mobileNumber;
		this.accountType = accountType;
		this.custAddress = custAddress;
		this.balance = balance;
	}

	public Account() {
	
	}
}
