package com.cg.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entities.Account;
import com.cg.entities.Transaction;
import com.cg.service.BankService;

import UserExceptions.AccountNotFoundException;

@RestController
@ComponentScan("com.cg")
public class UserController {

	@Autowired
	BankService service;

	@PostMapping(value = "/create")
	public Account createAccount(@Valid @RequestBody Account account) {
		return service.createAccount(account);
	}

	@GetMapping(value = "/showBalance/{accountNumber}")
	public long showBalance(@Valid @PathVariable String accountNumber) throws AccountNotFoundException {
		return service.showBalance(accountNumber);
	}

	@PutMapping(value = "/deposit/{accountNumber}/{balance}")
	public long deposit(@Valid @PathVariable String accountNumber, @PathVariable Long balance)
			throws AccountNotFoundException {
		return service.deposit(accountNumber, balance);
	}

	@PutMapping(value = "/withdraw/{accountNumber}/{balance}")
	public long withdraw(@Valid @PathVariable String accountNumber, @PathVariable Long balance)
			throws AccountNotFoundException {
		return service.withdraw(accountNumber, balance);

	}

	@PutMapping(value = "/transfer/{sAccountNumber}/{rAccountNumber}/{balance}")
	public List<Account> transfer(@Valid @PathVariable String sAccountNumber, @PathVariable String rAccountNumber,
			@PathVariable Long balance) throws AccountNotFoundException {
		return service.transfer(sAccountNumber, rAccountNumber, balance);
	}

	@GetMapping(value = "/print/{accountNumber}")
	public List<Transaction> printTransaction(@Valid @PathVariable String accountNumber)
			throws AccountNotFoundException {
		return service.printTranscation(accountNumber);
	}

	@ExceptionHandler(AccountNotFoundException.class)
	public ResponseEntity<String> accountNotFound(AccountNotFoundException e) {
		return new ResponseEntity<String>(e.getMessage(), HttpStatus.NOT_FOUND);
	}

}
